# RupeeMarket — Digital Package Marketplace

A responsive React + Firebase marketplace starter. Sellers can upload digital packages, buyers can pay in INR through HDFC Bank SmartGateway checkout (UPI/cards/netbanking methods depend on HDFC SmartGateway merchant-account eligibility), and the server verifies payment before allowing study lessons.

## Included
- Email/password sign-in and sign-up with Firebase Authentication
- Package catalogue and package upload form
- Firebase Storage for private package files
- Firestore package records and purchase records
- Node/Express backend for HDFC SmartGateway checkout-session creation, server-side payment-status verification, and buyer-only lesson streaming
- Firebase Storage and Firestore security rules
- Responsive UI

## Important before real payments
This is a starter project, not a deployed or audited production service. Use the HDFC SmartGateway test/sandbox environment and merchant-issued credentials first. Real payments require HDFC merchant onboarding and approval. Never put HDFC SmartGateway secrets or Firebase Admin credentials in frontend code. A parent/guardian may need to handle account onboarding and compliance. Add moderation, refund handling, seller payout logic, abuse reporting, rate limits, and legal/privacy pages before launching publicly.

## Requirements
- Node.js 20+ (Node 24 should work)
- A Firebase project with Authentication (Email/Password), Firestore, and Storage enabled
- HDFC SmartGateway merchant account and sandbox/API credentials

## 1. Configure Firebase
In Firebase Console:
1. Create a project.
2. Enable Authentication → Sign-in method → Email/Password.
3. Create a Firestore database.
4. Enable Firebase Storage.
5. Add a Web App and copy its config.
6. In Project Settings → Service accounts, generate a private key JSON for the backend. Keep it secret and do not commit it.

Copy `frontend/.env.example` to `frontend/.env` and fill in the Firebase web config.
Copy `backend/.env.example` to `backend/.env` and fill in the server settings and HDFC SmartGateway sandbox credentials.
Put your service account JSON at `backend/serviceAccountKey.json` (or set `GOOGLE_APPLICATION_CREDENTIALS` to its path). Never publish this file.

## 2. Configure Firestore and Storage rules
Publish the rules from `firebase/firestore.rules` and `firebase/storage.rules` in the Firebase Console. The storage rules allow a signed-in seller to upload to their own upload path, but only the backend should issue view URLs to buyers. Package files are not publicly readable.

## 3. Run locally
Open two terminals.

Terminal A:
```bash
cd backend
npm install
npm run dev
```

Terminal B:
```bash
cd frontend
npm install
npm run dev
```
Open the local URL printed by Vite (normally http://localhost:5173). Set `VITE_API_BASE_URL=http://localhost:4242` in `frontend/.env`.

## 4. Test checkout
Use HDFC SmartGateway sandbox credentials and its test payment methods. A buyer must be signed in. The backend creates an HDFC SmartGateway checkout session and checks the order status with HDFC before granting access. A browser return alone is not trusted. Verify the exact session/status endpoints and response fields against the documentation enabled for your HDFC merchant account before live deployment.

## 5. Before production
- Deploy backend over HTTPS and set `FRONTEND_URL` to the real website URL.
- Set `HDFC_API_KEY` and `HDFC_PAYMENT_PAGE_CLIENT_ID` on the backend host only.
- Set `HDFC SmartGateway merchant configuration` and configure the webhook.
- Set Firebase Auth authorized domains for your deployed domain.
- Add seller approval, file-type/size limits, malware scanning, content moderation, refunds, dispute handling, tax/accounting, privacy policy, terms, and age-appropriate account/payment arrangements.
- Do not claim that seller earnings are withdrawable until a compliant payout workflow is implemented.


## Study content and uploader restriction
- In `frontend/.env`, set `VITE_UPLOADER_EMAIL` to the exact uploader email.
- In `backend/.env`, set `UPLOADER_EMAIL` to the same exact email.
- In BOTH `firebase/firestore.rules` and `firebase/storage.rules`, replace `study-uploader@example.com` with that exact email, then publish the rules in Firebase Console.
- Verify that email in Firebase Authentication before uploading. The uploader account can add written notes and multiple video lessons to each package.
- Private written content is stored in the server-only `packageContents` collection. Firestore rules deny direct reads/writes to that collection. Video playback is streamed by the backend only after a paid purchase is found; no download button or public signed URL is provided.
- This is access control, not DRM: a determined viewer can still record a screen or capture displayed content. Video playback requires an authenticated session and paid purchase.
- The current upload form supports written notes plus video files (up to 500 MB each). For production, consider transcoding/streaming video through a dedicated video platform, rate limits, backups, content moderation, terms, privacy policy, and refund policy.
- Use HDFC SmartGateway sandbox credentials first. Payment gateway onboarding and a live merchant account may require a parent/guardian if the developer is under 18.


## HDFC SmartGateway configuration
- Create/activate an HDFC Bank SmartGateway merchant account and confirm whether your account uses the SmartGateway API Basic Auth integration.
- Set `HDFC_API_KEY`, `HDFC_PAYMENT_PAGE_CLIENT_ID`, and `HDFC_BASE_URL` in `backend/.env` or your hosting provider environment. Never expose these in the frontend.
- The code uses the SmartGateway `/session` checkout-session endpoint and `/orders/{order_id}` status lookup pattern. Confirm these exact endpoints, credentials, allowed return URL, and response fields with the merchant-specific HDFC documentation before live use.
- Official developer docs: https://smartgateway.hdfcbank.com/docs/ and bank gateway information: https://www.hdfc.bank.in/msme-banking/payment-gateway
- HDFC merchant onboarding/credentials are required; without them checkout stays disabled. Do not test live payments with real money until HDFC has approved the account and the integration has been tested in sandbox.
