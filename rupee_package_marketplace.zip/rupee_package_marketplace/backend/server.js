import "dotenv/config";
import express from "express";
import cors from "cors";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import admin from "firebase-admin";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 4242);
const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:5173";
const HDFC_API_KEY = process.env.HDFC_API_KEY || "";
const HDFC_PAYMENT_PAGE_CLIENT_ID = process.env.HDFC_PAYMENT_PAGE_CLIENT_ID || "";
const HDFC_BASE_URL = (process.env.HDFC_BASE_URL || "https://smartgateway.hdfcbank.com").replace(/\/$/, "");
const UPLOADER_EMAIL = (process.env.UPLOADER_EMAIL || "").trim().toLowerCase();

const servicePath = process.env.GOOGLE_APPLICATION_CREDENTIALS || path.join(__dirname, "serviceAccountKey.json");
if (!admin.apps.length) {
  if (fs.existsSync(servicePath)) {
    admin.initializeApp({ credential: admin.credential.cert(JSON.parse(fs.readFileSync(servicePath, "utf8"))), storageBucket: process.env.FIREBASE_STORAGE_BUCKET });
  } else {
    admin.initializeApp({ credential: admin.credential.applicationDefault(), storageBucket: process.env.FIREBASE_STORAGE_BUCKET });
  }
}
const db = admin.firestore();
const bucket = admin.storage().bucket();


app.use(cors({ origin: FRONTEND_URL.split(",").map(s => s.trim()), credentials: false }));
app.use(express.json({ limit: "1mb" }));

async function requireUser(req, res, next) {
  try {
    const authHeader = req.headers.authorization || "";
    if (!authHeader.startsWith("Bearer ")) return res.status(401).json({ error: "Sign in is required." });
    const decoded = await admin.auth().verifyIdToken(authHeader.slice(7));
    req.user = decoded;
    next();
  } catch { res.status(401).json({ error: "Your session is invalid or expired. Please sign in again." }); }
}

async function requireUserFromHeaderOrQuery(req, res, next) {
  try {
    const authHeader = req.headers.authorization || "";
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : String(req.query.auth || "");
    if (!token) return res.status(401).json({ error: "Sign in is required to stream this lesson." });
    req.user = await admin.auth().verifyIdToken(token);
    next();
  } catch { res.status(401).json({ error: "Your session is invalid or expired. Reload the lesson and try again." }); }
}

async function grantPurchase(uid, packageId, orderDocId, amountPaise, paymentId) {
  const purchaseId = `${uid}_${packageId}`;
  const purchaseRef = db.collection("purchases").doc(purchaseId);
  await db.runTransaction(async tx => {
    const existing = await tx.get(purchaseRef);
    if (existing.exists) return;
    tx.set(purchaseRef, {
      uid, packageId, orderDocId, amountPaise, paymentId: paymentId || null,
      status: "paid", createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
  });
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "RupeeMarket API" }));

async function hdfcRequest(urlPath, options = {}) {
  if (!HDFC_API_KEY) throw new Error("HDFC SmartGateway is not configured. Add HDFC_API_KEY from your merchant dashboard.");
  const auth = Buffer.from(`${HDFC_API_KEY}:`).toString("base64");
  const response = await fetch(`${HDFC_BASE_URL}${urlPath}`, {
    ...options,
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    console.error("HDFC SmartGateway API error", response.status, data);
    throw new Error(data.error_message || data.message || `HDFC SmartGateway request failed (${response.status}).`);
  }
  return data;
}

app.post("/api/payments/create-order", requireUser, async (req, res) => {
  try {
    if (!HDFC_API_KEY || !HDFC_PAYMENT_PAGE_CLIENT_ID) return res.status(503).json({ error: "HDFC SmartGateway is not configured. Add HDFC_API_KEY and HDFC_PAYMENT_PAGE_CLIENT_ID from your approved merchant account." });
    const packageId = String(req.body?.packageId || "");
    if (!packageId || packageId.length > 160) return res.status(400).json({ error: "Invalid package." });
    const snap = await db.collection("packages").doc(packageId).get();
    if (!snap.exists || snap.data().status !== "published") return res.status(404).json({ error: "Package not found." });
    const pack = snap.data();
    if (pack.sellerId === req.user.uid) return res.status(400).json({ error: "You cannot purchase your own package." });
    const amountPaise = Number(pack.pricePaise);
    if (!Number.isInteger(amountPaise) || amountPaise < 100 || amountPaise > 10000000) return res.status(400).json({ error: "Package price is invalid." });
    const orderId = `RM${Date.now()}${crypto.randomBytes(4).toString("hex")}`.slice(0, 32);
    const returnUrl = new URL("/", FRONTEND_URL);
    returnUrl.searchParams.set("payment", "return");
    returnUrl.searchParams.set("packageId", packageId);
    returnUrl.searchParams.set("order_id", orderId);
    const amount = (amountPaise / 100).toFixed(2);
    const session = await hdfcRequest("/session", {
      method: "POST",
      body: JSON.stringify({
        order_id: orderId,
        amount,
        currency: "INR",
        customer_id: req.user.uid,
        customer_email: req.user.email || "",
        payment_page_client_id: HDFC_PAYMENT_PAGE_CLIENT_ID,
        action: "paymentPage",
        return_url: returnUrl.toString(),
        description: String(pack.title || "RupeeMarket Study Package").slice(0, 120),
        udf1: packageId
      })
    });
    const redirectUrl = session.payment_links?.web || session.payment_links?.mobile || session.payment_url || session.redirect_url;
    if (!redirectUrl || typeof redirectUrl !== "string" || !redirectUrl.startsWith("https://")) {
      console.error("HDFC response did not contain a valid checkout URL", session);
      return res.status(502).json({ error: "HDFC did not return a checkout URL. Confirm your SmartGateway product settings with HDFC support." });
    }
    await db.collection("paymentOrders").doc(orderId).set({ uid: req.user.uid, packageId, amountPaise, hdfcOrderId: orderId, status: "created", createdAt: admin.firestore.FieldValue.serverTimestamp() });
    res.json({ orderId, redirectUrl, amount, currency: "INR" });
  } catch (e) { console.error("HDFC create order error", e); res.status(502).json({ error: e.message || "Could not start HDFC checkout." }); }
});

app.post("/api/payments/verify", requireUser, async (req, res) => {
  try {
    const { orderId, packageId } = req.body || {};
    if (typeof orderId !== "string" || typeof packageId !== "string" || !orderId || !packageId) return res.status(400).json({ error: "Missing HDFC order verification fields." });
    const orderDoc = await db.collection("paymentOrders").doc(orderId).get();
    if (!orderDoc.exists) return res.status(404).json({ error: "Payment order not found." });
    const order = orderDoc.data();
    if (order.uid !== req.user.uid || order.packageId !== packageId) return res.status(403).json({ error: "This payment order does not belong to you." });
    if (order.status === "paid") return res.json({ verified: true });
    const status = await hdfcRequest(`/orders/${encodeURIComponent(orderId)}`, { method: "GET", headers: { "Content-Type": "application/json" } });
    const paymentStatus = String(status.status || status.order_status || "").toUpperCase();
    const amountValue = Number(status.amount);
    const currency = String(status.currency || "INR").toUpperCase();
    if (paymentStatus !== "CHARGED" && paymentStatus !== "SUCCESS") return res.status(409).json({ error: `HDFC payment status is ${paymentStatus || "pending"}. Access has not been granted.` });
    if (Number.isFinite(amountValue) && Math.round(amountValue * 100) !== order.amountPaise) return res.status(400).json({ error: "HDFC payment amount does not match the package price." });
    if (currency !== "INR") return res.status(400).json({ error: "HDFC payment currency does not match INR." });
    const paymentId = String(status.txn_id || status.payment_id || status.id || orderId);
    await grantPurchase(req.user.uid, packageId, orderDoc.id, order.amountPaise, paymentId);
    await orderDoc.ref.update({ status: "paid", paymentId, paidAt: admin.firestore.FieldValue.serverTimestamp(), gatewayStatus: paymentStatus });
    res.json({ verified: true });
  } catch (e) { console.error("HDFC verify payment error", e); res.status(502).json({ error: e.message || "Could not verify HDFC payment. If money was deducted, do not pay again; contact support." }); }
});

async function requireUploader(req, res, next) {
  if (!UPLOADER_EMAIL) return res.status(503).json({ error: "Set UPLOADER_EMAIL in backend/.env before publishing content." });
  if (!req.user?.email || req.user.email.toLowerCase() !== UPLOADER_EMAIL || req.user.email_verified !== true) {
    return res.status(403).json({ error: "Only the configured, email-verified uploader can publish study packages." });
  }
  next();
}

app.put("/api/packages/:packageId/content", requireUser, requireUploader, async (req, res) => {
  try {
    const packageId = String(req.params.packageId || "");
    const { notes = "", videos = [] } = req.body || {};
    if (!packageId || packageId.length > 160 || typeof notes !== "string" || notes.length > 150000 || !Array.isArray(videos) || videos.length > 20) {
      return res.status(400).json({ error: "Invalid study content or too many videos." });
    }
    const packageSnap = await db.collection("packages").where("id", "==", packageId).limit(1).get();
    if (packageSnap.empty) return res.status(404).json({ error: "Package record not found." });
    const packDoc = packageSnap.docs[0];
    if (packDoc.data().sellerId !== req.user.uid) return res.status(403).json({ error: "You do not own this package." });
    for (const video of videos) {
      if (!video || typeof video.storagePath !== "string" || !video.storagePath.startsWith(`seller-uploads/${req.user.uid}/${packageId}/`) || typeof video.fileName !== "string" || typeof video.contentType !== "string" || !video.contentType.startsWith("video/")) {
        return res.status(400).json({ error: "A video reference is invalid." });
      }
    }
    await db.collection("packageContents").doc(packageId).set({ notes, videos, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    res.json({ saved: true });
  } catch (e) { console.error("Save content error", e); res.status(500).json({ error: "Could not save study content." }); }
});

async function requirePaidBuyer(req, res, packageId) {
  const purchase = await db.collection("purchases").doc(`${req.user.uid}_${packageId}`).get();
  if (!purchase.exists || purchase.data().status !== "paid") { res.status(403).json({ error: "Purchase not found. Complete payment first." }); return false; }
  return true;
}

app.get("/api/purchases/:packageId/content", requireUser, async (req, res) => {
  try {
    if (!await requirePaidBuyer(req, res, req.params.packageId)) return;
    const snap = await db.collection("packageContents").doc(req.params.packageId).get();
    if (!snap.exists) return res.status(404).json({ error: "Study content is not available yet." });
    const data = snap.data();
    res.json({ notes: data.notes || "", videos: (data.videos || []).map(v => ({ title: v.title || v.fileName, fileName: v.fileName, contentType: v.contentType })) });
  } catch (e) { console.error("Read content error", e); res.status(500).json({ error: "Could not load study content." }); }
});

app.get("/api/purchases/:packageId/video/:index", requireUserFromHeaderOrQuery, async (req, res) => {
  try {
    if (!await requirePaidBuyer(req, res, req.params.packageId)) return;
    const snap = await db.collection("packageContents").doc(req.params.packageId).get();
    if (!snap.exists) return res.status(404).json({ error: "Study content not found." });
    const index = Number(req.params.index); const videos = snap.data().videos || [];
    if (!Number.isInteger(index) || index < 0 || index >= videos.length) return res.status(404).json({ error: "Video not found." });
    const video = videos[index];
    if (typeof video.storagePath !== "string" || !video.storagePath.startsWith("seller-uploads/")) return res.status(500).json({ error: "Video storage reference is invalid." });
    const file = bucket.file(video.storagePath);
    const [meta] = await file.getMetadata();
    const size = Number(meta.size || 0); const range = req.headers.range;
    res.setHeader("Content-Type", video.contentType || "video/mp4");
    res.setHeader("Content-Disposition", "inline");
    res.setHeader("Cache-Control", "private, no-store, max-age=0");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Accept-Ranges", "bytes");
    if (range) {
      const match = /^bytes=(\d*)-(\d*)$/.exec(range);
      if (!match) return res.status(416).end();
      let start = match[1] ? Number(match[1]) : 0;
      let end = match[2] ? Number(match[2]) : size - 1;
      if (!match[1] && match[2]) { const suffix = Number(match[2]); start = Math.max(0, size - suffix); end = size - 1; }
      if (start >= size || end < start) { res.setHeader("Content-Range", `bytes */${size}`); return res.status(416).end(); }
      end = Math.min(end, size - 1);
      res.status(206); res.setHeader("Content-Range", `bytes ${start}-${end}/${size}`); res.setHeader("Content-Length", end - start + 1);
      file.createReadStream({ start, end }).on("error", e => { console.error("Video stream error", e); if (!res.headersSent) res.status(500); res.end(); }).pipe(res);
    } else {
      res.setHeader("Content-Length", size);
      file.createReadStream().on("error", e => { console.error("Video stream error", e); if (!res.headersSent) res.status(500); res.end(); }).pipe(res);
    }
  } catch (e) { console.error("Video view error", e); if (!res.headersSent) res.status(500).json({ error: "Could not stream this lesson video." }); }
});

app.get("/api/purchases", requireUser, async (req, res) => {
  try {
    const snap = await db.collection("purchases").where("uid", "==", req.user.uid).where("status", "==", "paid").get();
    const purchases = [];
    for (const doc of snap.docs) {
      const d = doc.data();
      const p = await db.collection("packages").doc(d.packageId).get();
      if (!p.exists) continue;
      purchases.push({ purchaseId: doc.id, packageId: d.packageId, title: p.data().title || "Digital package", fileName: p.data().fileName || "package", amountPaise: d.amountPaise, createdAt: d.createdAt?.toDate?.().toISOString() || null });
    }
    res.json({ purchases });
  } catch (e) { console.error("Purchases error", e); res.status(500).json({ error: "Could not load purchases." }); }
});


app.listen(PORT, () => console.log(`RupeeMarket API listening on http://localhost:${PORT}`));
